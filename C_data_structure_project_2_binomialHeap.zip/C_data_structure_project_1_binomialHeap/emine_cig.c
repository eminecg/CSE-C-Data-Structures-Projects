/*CSE2025 Data Structures PROJECT#2
 *
 * Emine Çığ 150118012
 *
 *The program  try to rank the documents according to the similarities between keyword (case insensitive) from user and the documents inside each file of the directory.
 *The similarity score is calculated for each file to depend on the keyword.
 *Program constructs a Binomial Max-Heap for extracting 5 relevant documents and printing each of it
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <ctype.h>


//Heap struct is created depend on the keyword
struct doc{

    // docName variable to hold name of each doc file
    char  docName[30] ;
    int degree;// number of children
    int similarityScore;// key
    struct doc *parent;// parent of each node
    struct doc *child;//left most child
    struct doc *sibling;// right sibling

};
typedef struct doc Doc;

// Doc object for holding first root of the Binomial Heap
Doc * H;
Doc * tempH;

//Key value is obtained by user and used for creating Binomial Heap
char  keyword[25];
// Score value is to hold similarity value of keyword with current doc content
int score;

//The number of doc which is include keyword at least 1 times
int relevantDocNmbr=0;


// Function prototypes
char *trim(char *s);
Doc * newDoc (int score, char *name);//name array olcak
Doc * enqueueDoc(Doc * nDoc,Doc* head);
Doc* docMerge(Doc* head1,Doc* head2);
Doc*  dequeueMaxDoc(Doc* head);
void checkWord(char word[]);
char* setFileAddress( const char* path, const char* filename );
int cutWord(char * source,char docName[25]);
void setChildSiblings(Doc * node);


// Trim function to get rid of unnecessary space of given char array
char *trim(char *s)
{
    char* back = s + strlen(s);

    while(isspace(*s)) s++;
    while(isspace(*--back));

    *(back+1) = '\0';
    return s;

}

//Function creates new node pointer for Binomial Heap and allocate memory for it with using given similarity score and name of doc
Doc * newDoc (int score, char* name){

    Doc* newD=(Doc*)malloc(sizeof(Doc));
    strcpy(newD->docName,name);
    newD->similarityScore=score;
    return newD;
}
//Function inserts the new doc to the Max Binomial Heap (head ) using docMerge function
Doc * enqueueDoc(Doc * nDoc,Doc* head){

    //Updates variable of new doc node
    Doc *temp = NULL;
    temp=nDoc;

    nDoc->degree=0;
    nDoc->parent=NULL;
    nDoc->sibling=NULL;
    nDoc->child=NULL;

    head=docMerge(head,temp);
    return head;

}
//Function merges into one MAX-HEAP structure with given two heap, and return new heap
Doc* docMerge(Doc* head1,Doc* head2){
    Doc* head =NULL;
    Doc* temp;

    //These pointers hold next and previous sibling node of the current node
    Doc* next;
    Doc* previous;

    // Creates temp pointers for merging two binomial heap tree
    Doc* headTemp=NULL;
    Doc* tempH1=head1;
    Doc* tempH2=head2;

    //Check for roots is empty or not and change root of the headTemp heap.
    // If both of empty , updates headTemp of heap,depend on the degree value of each one
    // If one of heap is empty,updates headTemp with non-empty heap
    if(tempH1!=NULL && tempH2!=NULL){

        if( tempH1->degree<=tempH2->degree){
            headTemp=tempH1;
        }
        else if ( tempH1->degree > tempH2->degree){
            headTemp=tempH2;
        }
    }
    else if(tempH1!=NULL &&tempH2==NULL){
        // tempH2 is empty
        headTemp=tempH1;
    }
    else{// tempH1 is empty
        headTemp=tempH2;
    }

    //Sets the siblings of the two heap depend on the degree until one of heap become empty
    // If conditions for to determine sibling change depend on degree comparison
    while(tempH1!=NULL&& tempH2 !=NULL){

        if(tempH1->degree <tempH2->degree){
            tempH1=tempH1->sibling;
        }

            // If heaps have same degree value
        else if(tempH1->degree==tempH2->degree){
            temp=tempH1->sibling;
            tempH1->sibling=tempH2;
            tempH1=temp;
        }else{
            temp=tempH2->sibling;
            tempH2->sibling=tempH1;
            tempH2=temp;
        }
    }
    // Updates head with headTemp which is changed upper operations
    head=headTemp;

    // Assign NULL to temp doc pointer to use again
    temp=NULL;

    // Checks both heap are empty so head become empty, if so function returns empty head
    if(head==NULL) {
        return head;
    }
    else{
        //Updates temp for protect head value
        temp=head;
        next=temp->sibling;
        previous=NULL;

        // Sets the sub nodes of heap as Max-Heap structure depend on the similarity score until next become NULL.
        while(next!=NULL){

            if((next->sibling != NULL && ((next->sibling)->degree == temp->degree)) || (temp->degree != next->degree)){
                previous=temp;
                temp=next;
            }
            else{ // For Max-Heap structure , checks similarity score and updates link between binomial trees

                if(temp->similarityScore>=next->similarityScore){
                    //Sets as next is a sub node of the temp
                    temp->sibling=next->sibling;
                    next->parent=temp;
                    next->sibling=temp->child;
                    temp->child=next;
                    temp->degree=(temp->degree)+1;
                }
                else{
                    if(previous!=NULL)
                        previous->sibling=next;
                    else
                        head=next;

                    //Sets as temp is a sub node of the next
                    temp->parent=next;
                    temp->sibling=next->child;
                    next->child=temp;
                    next->degree=(next->degree)+1;

                    // Updates temp value after settings
                    temp=next;
                }
            }
            //Updates next with following sibling at each cycle
            next=temp->sibling;
        }
        return head;
    }
}


// Function for extract most relevant node from Max Binomial Heap structure which has highest similarity score
// depend on the given keyword from user. Sets the structure of the heap when removing most relevant node.
Doc*  dequeueMaxDoc(Doc* head){

    //Doc pointers for setting node changes
    Doc* tempSib=head;
    Doc* currentDoc=NULL;

    Doc* temp;
    temp=tempSib;

    //Global Doc node pointer for holding with least child
    tempH=NULL;

    // Updates max value with first root of the heap
    int max=head->similarityScore;

    // Check for head is empty or not
    if(tempSib!=NULL){

        while(temp->sibling != NULL){

            //Compares max value with following sibling node's similarity score value
            //If so , updates max value and currentDoc node

            if(max  >= (temp->sibling)->similarityScore){
                //Updates temp with following sibling node
                temp=temp->sibling;
            }
            else{
                max=(temp->sibling)->similarityScore;
                currentDoc=temp;
                tempSib=temp->sibling;
            }

        }
        // Check for nodes are empty or not
        if( (tempSib->sibling==NULL) && (currentDoc==NULL) ){
            head=NULL;
        }
        else if(currentDoc==NULL){
            head=tempSib->sibling;
        }
        else if(currentDoc->sibling == NULL){
            currentDoc=NULL;
        }

        else{
            currentDoc->sibling=tempSib->sibling;
        }

        //After checking tempSib has child ,calls setChildSibling function for update tempH
        // with the node with the fewest children and reverts the heap
        if(tempSib->child!=NULL){
            setChildSiblings(tempSib->child);
            (tempSib->child)->sibling=NULL;
        }

        // Merges given head and tempH heaps and update global variable H,first root of heap
        H=docMerge(head,tempH);

        // Returns extracted Doc node pointer
        return tempSib;

    }
    else{
        printf("\nHEAP IS EMPTY !\n");
        return tempSib;
    }
}
// Recursive function for move each node's sibling two sibling next after reaching base case.
// Given heap  become inverted, Also updates tempH at the base case with the node with the fewest children
void setChildSiblings(Doc * node ){
    // Base condition
    if(node->sibling==NULL){
        tempH=node;
    }
    else{
        setChildSiblings(node->sibling);
        (node->sibling)->sibling=node;

    }
}

// Sets as an address with the given path and given file name, return this address
char* setFileAddress( const char* path, const char* filename )
{
    size_t n = strlen( path ) +  sizeof( "\\" )+ strlen( filename ) ;

    char *address = malloc( n * sizeof( char ) );

    address[0] = '\0';

    strcat( address, path );
    strcat( address, "\\" );
    strcat( address, filename );

    return address;

}

// Function splits each word without any punctuation mark of the given source string of the each doc content
// and using each word ,calls checkWord function for compare keyword.
int cutWord(char * source,char docName[25]){

    // temp variable holds first word without all punctuation mark and new line character
    char *temp = strtok(source , ",(?=([^\"]\"[^\"]\")[^\"]$) ,.:+-!***\n_");

    //Creates a Doc pointer to insert heap after getting similarity score of source string
    Doc * docPtr=NULL;

    while(temp!=NULL) {

        // Calls trim function before comparing keyword to sure to get rid of unnecessary  whitespace
        checkWord(trim(temp));

        //Splits following word without any punctuation mark from remain string until temp become null
        temp = strtok(NULL ,",(?=([^\"]\"[^\"]\")[^\"]$) ,.:+-!***\n_");
    }

    //Creates a new doc with given current score and doc name
    docPtr = newDoc(score,docName);

    //Inserts new doc to the heap , updates  head of heap
    H = enqueueDoc( docPtr,H);

    //If doc include keyword at least one , increases number of relevance doc
    if(score>0){
        relevantDocNmbr++;
    }
    //Assign 0 to score for next word split operation
    score=0;
}

//Function for comparing each word with the given keyword , if there is equality, the score is increased
void checkWord(char word[]){
    if(strcmpi(word,keyword)==0){
        score=score+1;
    }
}

int main(int argc, char **argv)
{

    //Requested number of relevant document
    int extractedDocNmbr=5;
    //The number of document inside directory
    int totalDocNmbr=0;

    //An Doc pointer type of array to hold 5 relevant doc object
    Doc *relevantDocs [extractedDocNmbr];

    // Ask the user for keyword to search inside each document file in given files folder
    printf("\n%s ","Keyword for searching : ");
    scanf("%s",keyword);
    printf("\nThe search operation for the keyword ' %s ' starting : \n",keyword);

    // Creates a DIR and dirent pointer objects to open directory
    DIR* dir;
    struct dirent* direntPtr;

    // Creates a FILE object for open file
    FILE    *filePtr;

    char baseAddress[]="..\\files";


    // Checks dir object can open , if it can not be open prints a warning for the user
    if (NULL == (dir = opendir (baseAddress)))
    {
        fprintf(stderr, "Error : Failed to open input directory at %s\n",baseAddress);

    }else{
        // Starts to read dir object
        while ((direntPtr = readdir(dir)))
        {
            // Continue current and parent directory
            if (!strcmp (direntPtr->d_name, "."))
                continue;
            if (!strcmp (direntPtr->d_name, ".."))
                continue;

            //Updates number of document
            totalDocNmbr++;

            //Opens fore reading to the each file inside current dirent object , updates the filePtr
            filePtr = fopen(setFileAddress(baseAddress,direntPtr->d_name), "rb");


            // Checks filePtr object is null or not , if it is NULL prints a warning for the user
            if (filePtr == NULL)
            {
                fprintf(stderr, "Error : Failed to open entry file - %s\n",direntPtr->d_name);

                return 1;
            }


            //Using fseek function , moves the file pointer position to the end of the file
            // and gets size of file with ftell function ,
            // then moves the file pointer position at the beginning again
            fseek(filePtr, 0, SEEK_END);
            long fileSize = ftell(filePtr);
            fseek(filePtr, 0, SEEK_SET);

            // Allocates memory for buffer of doc file
            char* buffer = malloc(fileSize + 1);
            buffer[fileSize]='\0';

            if(buffer==NULL){
                continue;
            }
            else{// Starts to read the current file
                fread(buffer, 1, fileSize, filePtr);


                //Following function splits each word ,compare them with keyword from user and
                // calls another functions to create Max Binomial Heap Structure depend on the given keyword from user
                cutWord(buffer,direntPtr->d_name);

                // free the memory of the buffer for next read operation
                free(buffer);

            }

        }
        //Extract 5 document operation is performing

        //Extracted node one of the relevant 5 documents with the keyword.
        Doc * extracted;

        printf("\nNUMBER OF RELEVANT DOCUMENTS is %d (Total number of documents : %d)\n", relevantDocNmbr,totalDocNmbr);
        printf("\nThe relevance order is: \n");


        int i;
        for (i=0; i < extractedDocNmbr; i++){
            //dequeueMaxDoc function for obtain most relevant node in max binomial heap
            // which has highest similarity score depend on the keyword from user
            extracted= dequeueMaxDoc(H);

            //
            relevantDocs[i]=extracted;

            if(i==4){
                printf("%s ( %d ).  ",extracted->docName,extracted->similarityScore);
            }
            else{
                printf("%s ( %d ),  ",extracted->docName,extracted->similarityScore);
            }
        }

        printf("\n\nContents of relevant documents :\n");

        // Prints each relevant doc string
        for(i=0;i<sizeof(relevantDocs)/sizeof(relevantDocs[0]);i++){
            filePtr = fopen(setFileAddress(baseAddress,relevantDocs[i]->docName), "rb");

            if (filePtr == NULL)
            {
                fprintf(stderr, "Error : Failed to open entry file \n");
                return 1;
            }

            fseek(filePtr, 0, SEEK_END);
            long fileSize = ftell(filePtr);
            fseek(filePtr, 0, SEEK_SET);

            char* buffer = malloc(fileSize + 1);
            buffer[fileSize]='\0';
            if(buffer==NULL){
                continue;
            }
            fread(buffer, 1, fileSize, filePtr);
            printf("\n\n%s ( %d )\n",relevantDocs[i]->docName,relevantDocs[i]->similarityScore);
            printf("\n%s",buffer);

        }

        // Close current file and last file pointer
        fclose(filePtr);
        closedir(dir);

        return 0;
    }
}