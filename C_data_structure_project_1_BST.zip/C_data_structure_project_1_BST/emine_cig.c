
// Emine Çığ 150118012
//
// CSE225 Data Structures, 2020(FALL)
// Project #1
//
// This project about the text classification studies.Program reads data from a text file and then creates a BST tree depend on the word key value and also
//creates a BT which is construct for minimize the total access time.Program calculates each of tree's total access time.
//We can discus relation of the total access time how it changes with result.

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// A struct node for obtain data ,it uses for the creating trees
struct node{

    int index;
    char word[20];
    int frequency ;

    struct node *left ;
    struct node *right ;
};
typedef struct node Node;

//Functions Prototypes

Node * insertBST (int index,char key[], int frequency,Node *p);
void in_order(Node *p);
void createArray(Node *p,Node* array[]);
int getDepth(struct node *node, char * key);
int find (Node *p, char *key,int depth);
void sortArray(Node *list[],int size);
Node* insertBT(Node* nodeArray[], Node* p,int i, int n);
Node* createNode(Node* nodeArray[],int i);


int main() {

    //Creates the root of the each tree and assign null
    Node* rootBST=NULL;
    Node* rootBT=NULL;

    // Create the file pointer
    FILE * sPtr;

    //Variables for obtain file data while reading
    char name[100];
    char word[25]={'\0'};
    int index,fre;

    // Open the file pointer
    sPtr=fopen("..\\input.txt","r");

    // Check file pointer whether is null  , if is not null start to reading data from the file
    if(sPtr==NULL){
        printf("\n%s","File could not be opened !");

    }
    else{
        // Check for remaining data
        while (!feof(sPtr)) {
            //Read a line from file
            while( fgets(name, 100, sPtr)){

                // Gets data from file and separate data to assign the appropriate value to each variable
                char *temp = strtok(name, ",");
                index = atoi(temp);
                temp = strtok(NULL, ",");
                strcpy(word, temp);
                temp = strtok(NULL, " ");
                fre = atoi(temp);

                // Insert root and other nodes depend on word key to the BST with updated variable for each line
                if(index==1){
                    rootBST=insertBST(index,word,fre,rootBST);
                }
                else{
                    insertBST(index,word,fre,rootBST);
                }

            }
        }
    }
    // Close the file
    fclose(sPtr);

    //Print the BST in LNR order with using in_order function (a)
    printf("%s","\n The LNR order of BST which is created on key of word : \n\n");
    in_order(rootBST);

    // Create an Node* type Array by using  BST and its size for calculating total access time fo BST and creating BT with the same data
    Node* nodeArray[index];
    createArray(rootBST,nodeArray);

    //Calculate Total Access Time in the BST (b).
    // Function first obtain depth of the each node in the tree by find function using array nodes for key value .
    //For each node value's access time is calculated as frequency *(depth value+1).Sum of all nodes access time gives total access time value
    int i;
    int totalAccess=0;
    for( i=0;i<index;i++){

        int levelAccess=nodeArray[i]->frequency*getDepth(rootBST,nodeArray[i]->word);
        totalAccess=totalAccess+levelAccess;
       // deptLevel=1;
    }
    printf("\n%s","--------------------------------------------------");
    printf("\n Total Number of Access Time of The BST : %d ",totalAccess);


    //Sorts the nodeArray depend on  frequency in descending order
    sortArray(nodeArray,index);

    //The insertBT function creates a BT for  minimize the total access time.
    //Call insertBT function to create BT with using nodeArray which is sorted in descending order of frequency
    //Nodes which has higher frequency values insert first to have less depth value.
    rootBT = insertBT(nodeArray, rootBT, 0, index);

    //Print the BT in LNR order with using in_order function (c)
    printf("\n%s","--------------------------------------------------");
    printf("%s","\n The LNR order of BT which is created on key of word : \n\n");
    in_order(rootBT);


    // Calculate total access time of BT tree which is created depend on frequency value
    int totalComparisonBT=0;
    for( i=0;i<index;i++){
        int deptLvl=getDepth(rootBT,nodeArray[i]->word);
        int levelComparison=nodeArray[i]->frequency*deptLvl;
        totalComparisonBT=totalComparisonBT+levelComparison;

    }
    printf("\n%s","--------------------------------------------------");
    printf("\n Total Number of Access Time of BT  :%d ",totalComparisonBT);
    printf("\n%s","--------------------------------------------------");

}
//The function insert a new element recursively to the BST ,
// checking appropriate location with comparing word value with starting root and other subtrees
Node * insertBST (int index,char key[], int frequency,Node *p){
    // returns a pointer to new node with key inserted in the BST.

    if (p == NULL) {
        //Allocate memory for new Node
        p=malloc(sizeof(Node));

        // Assigns value of the new Node variable using given parameter
        p->index=index;
        strcpy(p->word,key);
        p->frequency=frequency;
        p->left=NULL;
        p->right=NULL;

        return p;
    }
        // Compares word with key value

        // if key is less than current node's key ,calls itself with left of the current node
    else if (stricmp(p->word,key) >0 )
        p->left=insertBST(index,key,frequency,p->left);

        // if key is more than current node's key ,calls itself with right of the current node
    else if (stricmp(p->word,key)<=0)
        p->right=insertBST(index,key,frequency,p->right);

    // Key is found returns it
    return p;
}

//Prints BST tree in order LNR sequence
void in_order(Node *p){

    if (p!=NULL){
        in_order(p->left);
        printf("\n  %s , %d  ",p->word,p->frequency);
        in_order(p->right);
    }
}


// Create an Node* type of array recursively depend on the BST
int currentInd;
void createArray(Node *p,Node* array[]){

    if (p!=NULL){

        createArray(p->left,array);
        array[currentInd]=p;
        currentInd=currentInd+1;
        createArray(p->right,array);
    }
}
//The function for calculate the depth level of the given key value inside the given tree
int find (Node *p, char *key,int depth)
{
    if (p != NULL){

        if (stricmp(p->word,key)==0)	return depth;

        int nextDepth= find(p->left, key,depth+1);
        if (nextDepth != 0)
            return nextDepth;

        nextDepth=find(p->right, key,depth+1);
        return nextDepth;

    }

}
//The function for calling the find function with always depth value 1
int getDepth(struct node *node, char * key)
{
    return find(node,key,1);
}

// Function for sort given nodeArray in descending order of frequency value
void sortArray(Node *list[],int size){
    Node* temp;
    int i, j;

    for (i = 0; i < size - 1; i++)
    {
        for (j = 0; j < (size - 1-i); j++)
        {
            if (list[j]->frequency < list[j + 1]->frequency)
            {
                temp = list[j];
                list[j] = list[j + 1];
                list[j + 1] =temp;
            }
        }
    }
}

//The insertBT function creates a BT for minimize the total access time.
//Call insertBT function to create BT with using nodeArray which is sorted in descending order of frequency
//Nodes which has higher frequency values insert first to have less depth value.Function does the level order insertion .

Node* insertBT(Node* nodeArray[], Node* root,int i, int n)
{
    // Base case of function
    if (i < n)
    {
        Node* temp =createNode(nodeArray,i);
        root=temp;

        // insert left node to the tree
        root->left = insertBT(nodeArray,root->left, ((2 * i) + 1), n);

        // insert right node to the tree
        root->right = insertBT(nodeArray,root->right, ((2 * i )+ 2), n);
    }
    return root;
}
// This function using for allocate memory for new Node* object and set variable value with given array element
Node* createNode(Node* nodeArray[],int i){
    Node * p=(Node*) malloc (sizeof(Node));

    p->index=nodeArray[i]->index;
    strcpy(p->word,nodeArray[i]->word);
    p->frequency=nodeArray[i]->frequency;
    p->left=NULL;
    p->right=NULL;

    return p;
}
